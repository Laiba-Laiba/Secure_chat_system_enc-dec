#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <cstdlib>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/err.h>
#include <fstream>
#include <iomanip>
#include <ctime>
#include <regex>
#include <openssl/sha.h>
#include <cmath>

using namespace std;

// Function to calculate public key
long long calculatepublickey(long long base, long long private_key, long long prime) {
    long long result = 1;
    for (int i = 0; i < private_key; i++) {
        result = (result * base) % prime;  // Modular exponentiation
    }
    return result;
}

// Function to encrypt data using AES
int encrypt_aes(const unsigned char *plaintext, int plaintext_len, unsigned char *ciphertext, const unsigned char *key, unsigned char *iv) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;
    int ciphertext_len;

    // Initialize encryption
    EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), nullptr, key, iv);

    // Encrypt the data
    EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len);
    ciphertext_len = len;

    // Finalize encryption (adds padding)
    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    ciphertext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return ciphertext_len;  // Return total length of ciphertext
}

// Function to decrypt data using AES
int decrypt_aes(const unsigned char *ciphertext, int ciphertext_len, unsigned char *plaintext, const unsigned char *key, unsigned char *iv) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;
    int plaintext_len;

    // Initialize decryption
    EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), nullptr, key, iv);

    // Decrypt the data
    EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);
    plaintext_len = len;

    // Finalize decryption
    EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    plaintext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return plaintext_len;  // Return total length of plaintext
}

// Function to generate a random IV
void generate_iv(unsigned char *iv) {
    RAND_bytes(iv, 16);  // AES block size is 16 bytes
}

bool is_prime(int n) 
{
    if (n <= 1) return false; // Numbers less than 2 are not prime
    if (n <= 3) return true;  // 2 and 3 are prime numbers
    if (n % 2 == 0 || n % 3 == 0) return false; // Exclude multiples of 2 and 3

    for (int i = 5; i <= sqrt(n); i += 6) 
    { // Check for factors from 5 to sqrt(n)
        if (n % i == 0 || n % (i + 2) == 0) 
        {
            return false; // Found a divisor, n is not prime
        }
    }
    return true; // n is prime
}

// Function to generate a random prime number
int generate_prime(int p) 
{
    int prime;
    do 
    {
        prime = rand() % (p - 2) + 2; // Random number between 2 and 100
    } while (!is_prime(prime));
    return prime; // Return the generated prime number
}

// Function to check if a username already exists in the creds.txt file
bool check_username_exists(const string& username) 
{
    ifstream infile("creds.txt");
    string line;

    if (infile.is_open()) 
    {
        while (getline(infile, line)) 
        {
            if (line.find("Username: " + username) != string::npos) 
            {
                infile.close();
                return true;
            }
        }
        infile.close();
    }
    return false;
}

// Function to generate a random salt
string generate_salt() 
{
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    string salt;
    srand(time(0));
    for (int i = 0; i < 16; ++i) 
    {
        salt += charset[rand() % (sizeof(charset) - 1)];
    }
    return salt;
}

// Function to validate email format
bool is_valid_email(const string& email) 
{
    const regex pattern(R"(^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(com|pk|edu|org)$)");
    return regex_match(email, pattern);
}

// Function to check if password is valid (at least 6 characters and contains special character or number)
bool is_valid_password(const string& password) {
    if (password.length() < 6) {
        return false;  // Password is too short
    }

    bool contains_special_or_number = false;

    // Check if the password contains at least one number or special character
    for (char c : password) {
        if (isdigit(c) || ispunct(c)) {
            contains_special_or_number = true;
            break;
        }
    }

    return contains_special_or_number;  // Return true if it meets the criteria
}

// Function to hash the password with salt
string hash_password(const string& password, const string& salt) {
    string salted_password = password + salt;
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((unsigned char*)salted_password.c_str(), salted_password.size(), hash);

    ostringstream oss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        oss << hex << setw(2) << setfill('0') << (int)hash[i];
    }
    return oss.str();
}

int main() 
{    
     cout << "\n\n\t\t\t\t\t\t\033[35m*************************************************************************************\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                            ---CYBER SECURITY---                            \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ASSIGNMENT NO . 2                              \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                 LAIBA NASIR                                 \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ROLL NO . 23I-2079                             \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                    CYS-A                                    \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                   SECURE COMMUNICATION SYSTEM (SERVER END)                  \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m*************************************************************************************\033[0m\n";
    long long p = 7919;  // Prime number
    long long alpha = 2;  // Base

    // Create socket
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_address, client_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8080);
    server_address.sin_addr.s_addr = INADDR_ANY;

    bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address));
    listen(server_socket, 5);  // Listen for connections

    cout << "\n\n\t\t\t\t\t\t\t\t\033[36m --------SERVER IS LISTENING ON PORT 8080👂️--------\033[0m\n" << endl;
 
    
    while (true) 
    {
        socklen_t client_len = sizeof(client_address);
        int client_socket = accept(server_socket, (struct sockaddr*)&client_address, &client_len);

        cout << "\n\t\t\t\t\t\t\t\t\t\t\t\t\033[36m ---CLIENT CONNECTED--- 🤝️ \033[0m" << endl;

       bool endCases = false;
        while (!endCases) 
        {
            // Send a menu to the client
            const char *menu = "1- Register\n2- Login\n3- Exit\n";
            send(client_socket, menu, strlen(menu), 0);

            // Receive option from the client
            int option;
            int recv_status = recv(client_socket, reinterpret_cast<char*>(&option), sizeof(option), 0);
            if (recv_status <= 0) 
            { 
                cout << "\n\t\033[31m Error receiving option from client! \033[0m" << endl;
                close(client_socket);
                break;  // Break the inner loop to accept new client
            }

            if (option == 3)  // Exit
            { 
                const char *exit_message = "\n\t\t\033[1;36m ---EXITING---\033[0m\n";
                send(client_socket, exit_message, strlen(exit_message), 0);
                break;  // Exit the inner loop to accept new client
            }

            if (option == 1) 
            { 
                // Registration
                long long server_private_key = generate_prime(p);

                // Receive client's public key
                long long client_public_key;
                recv(client_socket, reinterpret_cast<char*>(&client_public_key), sizeof(client_public_key), 0);

                // Calculate server's public key
                long long server_public_key = calculatepublickey(alpha, server_private_key, p);
                send(client_socket, reinterpret_cast<char*>(&server_public_key), sizeof(server_public_key), 0);

                // Calculate shared key
                long long shared_key = calculatepublickey(client_public_key, server_private_key, p);
               
                
                
                    cout << "\n\t\t\t\t\t\t\033[46m ------- KEY EXCHANGED SUCCESSFULLY FOR REGISTRATION------ \033[0m" << endl;
                

                // Convert shared key to AES key
                unsigned char aes_key[16];
                for (int i = 0; i < 16; i++) {
                    aes_key[i] = (shared_key >> (8 * (15 - i))) & 0xFF;
                }

                // Receive IV from the client
                unsigned char iv[16];
                recv(client_socket, iv, sizeof(iv), 0);

                // Username loop
                string username;
                while (true) {
                    // Receive the length of the encrypted username
                    int encrypted_len;
                    recv(client_socket, reinterpret_cast<char*>(&encrypted_len), sizeof(encrypted_len), 0);

                    // Receive the actual encrypted username
                    unsigned char encrypted_username[256];
                    recv(client_socket, encrypted_username, encrypted_len, 0);

                    // Decrypt the username
                    unsigned char decrypted_username[256];
                    int decrypted_len = decrypt_aes(encrypted_username, encrypted_len, decrypted_username, aes_key, iv);
                    
                    if (decrypted_len < 0) 
                    {
                        cerr << "\n\n\033[31m Decryption failed!\033[0m" << endl;
                        close(client_socket);
                        break;
                    }

                    decrypted_username[decrypted_len] = '\0'; // Null-terminate the string
                    username = reinterpret_cast<char*>(decrypted_username);
                    cout << "\n\n\033[35m USERNAME DECRYPTED SUCCESSFULLY \033[0m"  << endl;

                    // Check if username already exists
                    if (check_username_exists(username)) 
                    {
                        const char *response = "Username already exists. Please choose another one.\n";
                        send(client_socket, response, strlen(response), 0);
                    } 
                    else 
                    {
                        send(client_socket, "Username is Unique", 18, 0);
                        break; // Exit the username loop
                    }
                }

                // Email loop
                string email;
                while (true) 
                {
                    // Receive the encrypted email
                    int encrypted_len;
                    recv(client_socket, reinterpret_cast<char*>(&encrypted_len), sizeof(encrypted_len), 0);
                    unsigned char encrypted_email[256];
                    recv(client_socket, encrypted_email, encrypted_len, 0);

                    // Decrypt the email
                    unsigned char decrypted_email[256];
                    int decrypted_email_len = decrypt_aes(encrypted_email, encrypted_len, decrypted_email, aes_key, iv);

                    if (decrypted_email_len < 0) 
                    {
                        cout << "\n\n\033[31m Decryption failed!\033[0m" << endl;
                        close(client_socket);
                        break;
                    }

                    decrypted_email[decrypted_email_len] = '\0'; // Null-terminate the string
                    email = reinterpret_cast<char*>(decrypted_email);
                    cout << " \n\n\033[35m EMAIL IS DECRYPTED SUCCESSFULLY \033[0m"  << endl;

                    // Validate the email format
                    if (!is_valid_email(email)) 
                    {
                        const char *response = "Invalid email format. Please enter a valid email.\n";
                        send(client_socket, response, strlen(response), 0);
                    } 
                    else 
                    {
                        // Email is valid
                        const char *response = "Email is valid";
                        send(client_socket, response, strlen(response), 0);
                        break; // Exit the email loop
                    }
                }

                // Password loop
                string password;
                while (true) 
                {
                    // Receive the encrypted password
                    int encrypted_len;
                    recv(client_socket, reinterpret_cast<char*>(&encrypted_len), sizeof(encrypted_len), 0);
                    unsigned char encrypted_password[256];
                    recv(client_socket, encrypted_password, encrypted_len, 0);

                    // Decrypt the password
                    unsigned char decrypted_password[256];
                    int decrypted_password_len = decrypt_aes(encrypted_password, encrypted_len, decrypted_password, aes_key, iv);

                    if (decrypted_password_len < 0) {
                        cout << "\n\n\033[31m Decryption failed!\033[0m" << endl;
                        close(client_socket);
                        break;
                    }

                    decrypted_password[decrypted_password_len] = '\0'; // Null-terminate the string
                    password = reinterpret_cast<char*>(decrypted_password);
                   cout << "\n\n\033[35m PASSWORD DECRYPTED SUCCESSFULLY \033[0m"  << endl;

                    // Validate the password
                    if (!is_valid_password(password)) 
                    {
                        const char *response = "Password must be at least 6 characters long and contain a number or special character.\n";
                        send(client_socket, response, strlen(response), 0);
                    } 
                    else 
                    { 
                        send(client_socket, "Valid Password", 14, 0);
                        // Generate salt
                        string salt = generate_salt();

                        // Hash the password with salt
                        string hashed_password = hash_password(password, salt);

                        // Save credentials
                        ofstream outfile("creds.txt", ios::app);
                        outfile << "Email: " << email << ", Username: " << username << ", Password: " << hashed_password << ", Salt: " << salt << "\n";
                        outfile.close();

                        const char *success_response = "Registration successful!\n";
                        send(client_socket, success_response, strlen(success_response), 0);
                        cout << "\n\n\t\t\t\t\t\t\t\t\033[36m --------REGISTRATION SUCCESSFUL-------- \033[0m"  << endl;
                        break; // Exit the password loop
                    }
                }
            }

    if (option == 2) 
{ 
    // Receive client's public key and generate shared key 
    long long client_public_key; 
    recv(client_socket, reinterpret_cast<long long*>(&client_public_key), sizeof(client_public_key), 0); 

    long long server_private_key = generate_prime(p); // Private key 
    long long server_public_key = calculatepublickey(alpha, server_private_key, p); 
    send(client_socket, reinterpret_cast<long long*>(&server_public_key), sizeof(server_public_key), 0); 

    long long shared_key = calculatepublickey(client_public_key, server_private_key, p); 

    cout << "\n\t\t\t\t\t\t\t\t\t\033[46m ------- KEY EXCHANGED SUCCESSFULLY FOR LOGIN------ \033[0m" << endl; 

    // Prepare AES key
    unsigned char aes_key[16]; 
    for (int i = 0; i < 16; i++) { 
        aes_key[i] = (shared_key >> (8 * (15 - i))) & 0xFF; 
    }

    // Receive IV 
    unsigned char iv[16]; 
    recv(client_socket, iv, sizeof(iv), 0); 

    // Username loop: Prompt for username until valid username is entered 
    string username; 
    bool exit = false;
    while (!exit) { 
        // Receive and decrypt username 
        int encrypted_username_len; 
        recv(client_socket, reinterpret_cast<char*>(&encrypted_username_len), sizeof(encrypted_username_len), 0); 
        
        unsigned char encrypted_username[256]; 
        recv(client_socket, encrypted_username, encrypted_username_len, 0); 
        
        unsigned char decrypted_username[256]; 
        int decrypted_len = decrypt_aes(encrypted_username, encrypted_username_len, decrypted_username, aes_key, iv); 
        decrypted_username[decrypted_len] = '\0'; // Null-terminate the string 
        username = reinterpret_cast<char*>(decrypted_username); 
        cout << "\n\n\033[35m USERNAME DECRYPTED SUCCESSFULLY \033[0m" << endl; 

        // Check if username exists in the file and extract the salt 
        bool username_found = false; 
        string stored_salt, stored_hashed_password; 
        ifstream user_file("creds.txt"); 
        string line; 
        
        while (getline(user_file, line)) 
        { 
            if (line.find("Username: " + username) != string::npos) 
            { 
                // Extract the corresponding salt and stored hashed password 
                size_t pos_salt = line.find("Salt: "); 
                size_t pos_password = line.find("Password: "); 
                if (pos_salt != string::npos && pos_password != string::npos) 
                { 
                    stored_salt = line.substr(pos_salt + 6, 16); // Assuming salt is 16 characters long 
                    stored_hashed_password = line.substr(pos_password + 10, 64); // SHA-256 hash is 64 characters long 
                } 
                username_found = true; 
                break; 
            } 
        } 
        user_file.close(); 
        
        // Send appropriate response to client 
        if (username_found) 
        { 
            string response = "Username found, please enter your password."; 
            send(client_socket, response.c_str(), response.size(), 0); 

            // Password loop - re-enter if incorrect 
            while (true) 
            { 
                // Receive the encrypted password 
                int encrypted_password_len; 
                recv(client_socket, reinterpret_cast<char*>(&encrypted_password_len), sizeof(encrypted_password_len), 0); 
                unsigned char encrypted_password[256]; 
                recv(client_socket, encrypted_password, encrypted_password_len, 0); 
                
                // Decrypt the password 
                unsigned char decrypted_password[256]; 
                int decrypted_password_len = decrypt_aes(encrypted_password, encrypted_password_len, decrypted_password, aes_key, iv); 
                string password(reinterpret_cast<char*>(decrypted_password), decrypted_password_len); 
                cout << "\n\n\033[35m PASSWORD DECRYPTED SUCCESSFULLY \033[0m" << endl; 
                
                // Hash the password with the stored salt 
                string hashed_password = hash_password(password, stored_salt); 
                
                // Compare the calculated hash with the stored hash 
                if (hashed_password != stored_hashed_password) 
                { 
                    string failure_message = "Invalid password. Please enter again."; 
                    send(client_socket, failure_message.c_str(), failure_message.size(), 0); 
                    cout << "\n\t\033[31m Invalid password, please try again\033[0m" << endl; 
                } 
                else 
                { 
                    string success_message = "Login Successful"; 
                    send(client_socket, success_message.c_str(), success_message.size(), 0); 
                    cout << "\n\n\t\t\t\t\t\t\t\033[36m --------LOGIN SUCCESSFUL-------- \033[0m" << endl; 

                    // Reuse the public key for chat
                    // Append username to shared key
                    long long final_shared_key = shared_key;
                    for (char c : username) {
                        final_shared_key += c;  // Simple way to append username
                    }
                    
                    
                    // Prepare for communication using the modified shared key
                    unsigned char chat_aes_key[16]; 
                    for (int i = 0; i < 16; i++) { 
                        chat_aes_key[i] = (final_shared_key >> (8 * (15 - i))) & 0xFF; 
                    }

                    // Receive IV for chat
                    unsigned char chat_iv[16]; 
                    recv(client_socket, chat_iv, sizeof(chat_iv), 0); 

                    // Communication loop 
                    while (true) 
                    { 
                        // Receive the length of the encrypted message 
                        int encrypted_message_len; 
                        recv(client_socket, reinterpret_cast<char*>(&encrypted_message_len), sizeof(encrypted_message_len), 0); 

                        // Receive the actual encrypted message 
                        unsigned char encrypted_message[256]; 
                        recv(client_socket, encrypted_message, encrypted_message_len, 0); 

                        // Decrypt the message 
                        unsigned char decrypted_message[256]; 
                        int decrypted_len = decrypt_aes(encrypted_message, encrypted_message_len, decrypted_message, chat_aes_key, chat_iv); 
                        decrypted_message[decrypted_len] = '\0';  // Null-terminate the decrypted message 
                        string message = reinterpret_cast<char*>(decrypted_message); 
                        
                        cout << endl; 
                        // Use char array instead of string for client message 
                        cout << username << ": " << message << endl; 

                        // Check for exit condition 
                        if (strncmp(reinterpret_cast<char*>(decrypted_message), "bye", 3) == 0) 
                        { 
                            cout << "\n\n\t\t\t\t\t\t\t\033[31m ****CLIENT DISCONNECTED***\033[0m" << endl;
                            cout << "\n\n\t\t\t\t\t\033[36m Server Waiting for other clients to connect \033[0m\n";
                            exit = true; 
                            
                            endCases=true;
                            break;  // Exit the communication loop 
                        } 

                        // Prepare the server's response 
                        char response[256]; 
                        cout << "\nYou: "; 
                        cin.getline(response, sizeof(response));  // Read response into char array 

                        // Encrypt the response 
                        unsigned char encrypted_response[256]; 
                        int encrypted_response_len = encrypt_aes(reinterpret_cast<const unsigned char*>(response), strlen(response), encrypted_response, chat_aes_key, chat_iv); 
                        
                        // Send the length of the encrypted response 
                        send(client_socket, reinterpret_cast<char*>(&encrypted_response_len), sizeof(encrypted_response_len), 0); 

                        // Send the actual encrypted response 
                        send(client_socket, encrypted_response, encrypted_response_len, 0); 
                    } 
                    break; // Exit password loop after successful login 
                } // End of password validation 
            } // End of password loop 
        } // End of username found 
        else 
        { 
            string response = "Username not found. Please try again."; 
            send(client_socket, response.c_str(), response.size(), 0); 
            // After sending the message, we loop back for the username input again 
        } 
    } // End of option 2 
}
        } // End of inner while loop for menu
        close(client_socket); // Close the connection
    } // End of main while loop
    close(server_socket); // Close the server socket
    return 0;
}

