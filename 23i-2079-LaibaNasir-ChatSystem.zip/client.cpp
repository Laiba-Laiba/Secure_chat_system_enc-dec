#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <cmath>

using namespace std;

// Function to calculate public key
long long calculatepublickey(long long base, long long private_key, long long prime) 
{
    long long result = 1;
    for (int i = 0; i < private_key; i++) 
    {
        result = (result * base) % prime;  // Modular exponentiation
    }
    return result;
}

// Function to encrypt data using AES
int encrypt_aes(const unsigned char *plaintext, int plaintext_len, unsigned char *ciphertext, const unsigned char *key, unsigned char *iv) 
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;
    int ciphertext_len;

    // Initialize encryption
    EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), nullptr, key, iv);

    // Encrypt the data
    EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len);
    ciphertext_len = len;

    // Finalize encryption (adds padding)
    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    ciphertext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return ciphertext_len;  // Return total length of ciphertext
}

// Function to decrypt data using AES
int decrypt_aes(const unsigned char *ciphertext, int ciphertext_len, unsigned char *plaintext, const unsigned char *key, unsigned char *iv) 
{
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;
    int plaintext_len;

    // Initialize decryption
    EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), nullptr, key, iv);

    // Decrypt the data
    EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);
    plaintext_len = len;

    // Finalize decryption
    EVP_DecryptFinal_ex(ctx, plaintext + len, &len);
    plaintext_len += len;

    EVP_CIPHER_CTX_free(ctx);
    return plaintext_len;  // Return total length of plaintext
}

// Function to generate a random IV
void generate_iv(unsigned char *iv) 
{
    RAND_bytes(iv, 16);  // AES block size is 16 bytes
}

// Function to trim spaces manually (leading and trailing)
string trim(const string& str) 
{
    int start = 0;
    while (start < str.length() && isspace(str[start])) 
    {
        start++;
    }

    int end = str.length() - 1;
    while (end >= 0 && isspace(str[end])) 
    {
        end--;
    }

    return str.substr(start, end - start + 1);
}

// Function to trim leading and trailing spaces from a character array
void trimmessage(char* str) 
{
    // Trim leading spaces
    while (isspace(*str)) str++;

    // Trim trailing spaces
    char* end = str + strlen(str) - 1;
    while (end > str && isspace(*end)) end--;

    // Null terminate after the last non-space character
    *(end + 1) = '\0';
}

// Function to convert a string to lowercase manually
string to_lowercase(const string& str) 
{
    string result = str;
    for (int i = 0; i < result.length(); i++) 
    {
        result[i] = tolower(result[i]);
    }
    return result;
}
bool is_prime(int n) 
{
    if (n <= 1) return false; // Numbers less than 2 are not prime
    if (n <= 3) return true;  // 2 and 3 are prime numbers
    if (n % 2 == 0 || n % 3 == 0) return false; // Exclude multiples of 2 and 3

    for (int i = 5; i <= sqrt(n); i += 6) { // Check for factors from 5 to sqrt(n)
        if (n % i == 0 || n % (i + 2) == 0) {
            return false; // Found a divisor, n is not prime
        }
    }
    return true; // n is prime
}

// Function to generate a random prime number
int generate_prime(int p) 
{
    int prime;
    do 
    {
        prime = rand() % (p - 2) + 2; // Random number between 2 and 100
    } while (!is_prime(prime));
    return prime; // Return the generated prime number
}

int main() 
{
       cout << "\n\n\t\t\t\t\t\t\033[35m*************************************************************************************\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                            ---CYBER SECURITY---                            \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ASSIGNMENT NO . 2                              \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                 LAIBA NASIR                                 \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                              ROLL NO . 23I-2079                             \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                                    CYS-A                                    \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m** \033[0m" << "\033[1;36m                   SECURE COMMUNICATION SYSTEM (CLIENT END)                  \033[0m   " << "\033[35m**\033[0m\n"

        << "            \t\t\t\t\t\033[35m**                                                                                 **\033[0m\n"

        << "            \t\t\t\t\t\033[35m*************************************************************************************\033[0m\n";
    long long p = 7919;  // Prime number
    long long alpha = 2;  // Base
     
    // Create socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(8080);
    inet_pton(AF_INET, "127.0.0.1", &server_address.sin_addr);

    // Connect to server
    connect(sock, (struct sockaddr*)&server_address, sizeof(server_address));
 
    bool exit_program = false;
    while (!exit_program) 
    {
    
        // Receive menu from server
        char menu[256];
        int bytes_received = recv(sock, menu, sizeof(menu) - 1, 0);
        menu[bytes_received] = '\0';  // Null-terminate the received string
        cout << menu;  // Display the menu

        // Send option to server
        int option;
        cout << "Enter option: ";
        cin >> option;
        send(sock, reinterpret_cast<char*>(&option), sizeof(option), 0);

        
        if (option == 1) 
        {
            // Generate private key and public key for registration
            long long client_private_key = generate_prime(p);  // Private key
            long long client_public_key = calculatepublickey(alpha, client_private_key, p);
            send(sock, reinterpret_cast<long long*>(&client_public_key), sizeof(client_public_key), 0);

            // Receive server's public key
            long long server_public_key;
            recv(sock, reinterpret_cast<long long*>(&server_public_key), sizeof(server_public_key), 0);

            // Calculate shared key
            long long shared_key = calculatepublickey(server_public_key, client_private_key, p);
            

            // Convert shared key to AES key
            unsigned char aes_key[16];
            for (int i = 0; i < 16; i++)
            {
                aes_key[i] = (shared_key >> (8 * (15 - i))) & 0xFF;
            }

            // Generate IV
            unsigned char iv[16];
            generate_iv(iv);

            // Send IV to server
            send(sock, iv, sizeof(iv), 0);

            // Get user input for registration
            string username, email, password;
            bool userexit = false;

            // Registration loop
            while (!userexit) 
            {
                cout << "\n\n\033[35m Enter username: \033[0m";
                cin >> username;

                // Encrypt username
                unsigned char encrypted_username[256];
                int encrypted_len = encrypt_aes(reinterpret_cast<const unsigned char*>(username.c_str()), username.length(), encrypted_username, aes_key, iv);

                // Send the length of the encrypted data
                send(sock, reinterpret_cast<char*>(&encrypted_len), sizeof(encrypted_len), 0);

                // Send the actual encrypted data
                send(sock, encrypted_username, encrypted_len, 0);

                char username_response[256];
                int response_len = recv(sock, username_response, sizeof(username_response) - 1, 0);
                if (response_len > 0) 
                {
                    username_response[response_len] = '\0';  // Null-terminate the response
                } 
                else 
                {
                    cout << "\n\t\033[31m Error receiving username response!\033[0m" << endl;
                    continue;
                }

                string response(username_response);  // Convert to std::string for easier handling
                response = trim(response);  // Remove any leading/trailing spaces
                response = to_lowercase(response);  // Convert to lowercase

                cout << "\n\n\033[36m Server response is :\033[0m" << response << endl;  // Print server response

                if (response == "username already exists. please choose another one") 
                {
                    continue;  // Prompt for username again
                } 
                else if (response == "username is unique") 
                {
                    userexit = true; // Exit the registration loop
                }
            }

            // Handle email input
            while (true) 
            {
                cout << "\n\n\033[35m Enter email: \033[0m";
                cin >> email;

                // Encrypt email
                unsigned char encrypted_email[256];
                int encrypted_email_len = encrypt_aes(reinterpret_cast<const unsigned char*>(email.c_str()), email.length(), encrypted_email, aes_key, iv);

                // Send the length of the encrypted data
                send(sock, reinterpret_cast<char*>(&encrypted_email_len), sizeof(encrypted_email_len), 0);

                // Send the actual encrypted data
                send(sock, encrypted_email, encrypted_email_len, 0);

                // Receive response for email
                char email_response[256];
                int email_response_len = recv(sock, email_response, sizeof(email_response) - 1, 0);
                if (email_response_len > 0) 
                {
                    email_response[email_response_len] = '\0';  // Null-terminate the response
                } 
                else 
                {
                    cerr << "\n\033[31m Error receiving email response!\033[0m" << endl;
                    continue;  // Retry the email input on error
                }

                string email_response_str(email_response);  // Convert to std::string
                cout << "\n\t\033[36m Server response: \033[0m" << email_response_str << endl;

                // Handle the email response
                if (email_response_str == "invalid email format. please re-enter.") 
                {
                    continue;  // Stay in this loop and prompt for email again
                } 
                else if (email_response_str == "Email is valid") 
                {
                    break;  // Exit the email loop
                }
            }

            // Now we handle password entry
            bool exit = false;
            while (!exit) 
            {  
                cout << "\n\n\033[35m Enter password: \033[0m";
                cin >> password;

                // Encrypt password
                unsigned char encrypted_password[256];
                int encrypted_password_len = encrypt_aes(reinterpret_cast<const unsigned char*>(password.c_str()), password.length(), encrypted_password, aes_key, iv);

                // Send the length of the encrypted data
                send(sock, reinterpret_cast<char*>(&encrypted_password_len), sizeof(encrypted_password_len), 0);

                // Send the actual encrypted data
                send(sock, encrypted_password, encrypted_password_len, 0);

                // Receive password response from server
                char password_response[256];
                int password_response_len = recv(sock, password_response, sizeof(password_response) - 1, 0);
                if (password_response_len > 0) 
                {
                    password_response[password_response_len] = '\0';  // Null-terminate the response
                } 
                else 
                {
                    cerr << "\n\t\033[31m Error receiving password response! \033[0m" << endl;
                    continue;  // Retry password input on error
                }

                string password_response_str(password_response);  // Convert to std::string
                cout << "\n\t\033[36m Server response: \033[0m" << password_response_str << endl;

                // Handle the password response
                if (password_response_str == "invalid password format. please re-enter.") 
                {
                    // Continue to prompt for password again if invalid
                    continue;  
                } 
                else if (password_response_str == "Valid Password") 
                {
                   exit = true;
                    // Receive registration response
                    char finalmsg[256];
                    int final_msg_len = recv(sock, finalmsg, sizeof(finalmsg) - 1, 0);
                    if (final_msg_len > 0) 
                    {
                        finalmsg[final_msg_len] = '\0';  // Null-terminate the response
                    } 
                    else 
                    {
                        cout << "\n\n\033[31m Error receiving final message!\033[0m" << endl;
                        continue;
                    }
                    string finalmessage(finalmsg);  // Convert to std::string
                    cout <<"\n\n"<< finalmessage <<endl<<endl;  // Show the final message
                    break;  // Exit the password loop
                }
            }

            // After successful registration, return to the main menu
            //continue;  // This will make the outer while loop show the menu again
        }

       if (option == 2) 
{
    // Generate new keys
    long long client_private_key = generate_prime(p);  // Private key
    long long client_public_key = calculatepublickey(alpha, client_private_key, p);
    send(sock, reinterpret_cast<long long*>(&client_public_key), sizeof(client_public_key), 0);

    // Receive server's public key
    long long server_public_key;
    recv(sock, reinterpret_cast<long long*>(&server_public_key), sizeof(server_public_key), 0);

    // Calculate shared key
    long long shared_key = calculatepublickey(server_public_key, client_private_key, p);

    // Convert shared key to AES key
    unsigned char aes_key[16];
    for (int i = 0; i < 16; i++) 
    {
        aes_key[i] = (shared_key >> (8 * (15 - i))) & 0xFF;
    }

    // Generate IV
    unsigned char iv[16];
    generate_iv(iv);
    send(sock, iv, sizeof(iv), 0);

    // User input for username
    string username;
    while (true) 
    {
        cout << "\n\n\033[35m Enter username: \033[0m";
        cin >> username;

        // Encrypt username
        unsigned char encrypted_username[256];
        int encrypted_len = encrypt_aes(reinterpret_cast<const unsigned char*>(username.c_str()), username.length(), encrypted_username, aes_key, iv);

        // Send the length and actual encrypted username
        send(sock, reinterpret_cast<char*>(&encrypted_len), sizeof(encrypted_len), 0);
        send(sock, encrypted_username, encrypted_len, 0);

        // Receive server's response
        char username_response[256];
        int response_len = recv(sock, username_response, sizeof(username_response) - 1, 0);
        username_response[response_len] = '\0';
        string response(username_response);
        response = trim(response);
        response = to_lowercase(response);

        cout << "\n\t\033[36m Server response: \033[0m" << response << endl;

        if (response == "username not found. please enter again") 
        {
            continue;  // Prompt for username again
        } 
        else if (response == "username found, please enter your password.") 
        {
            break;  // Exit the username loop after successful login
        }
    }

    // Handle password input
    bool exit = false;
    while (!exit) 
    {
        string password;
        cout << "\n\n\033[35m Enter password: \033[0m";
        cin >> password;

        // Encrypt the password
        unsigned char encrypted_password[256];
        int encrypted_password_len = encrypt_aes(reinterpret_cast<const unsigned char*>(password.c_str()), password.length(), encrypted_password, aes_key, iv);

        // Send the length of the encrypted password
        send(sock, reinterpret_cast<char*>(&encrypted_password_len), sizeof(encrypted_password_len), 0);

        // Send the actual encrypted password
        send(sock, encrypted_password, encrypted_password_len, 0);

        // Receive server's response for the password
        char password_response[256];
        int password_response_len = recv(sock, password_response, sizeof(password_response) - 1, 0);
        if (password_response_len > 0) 
        {
            password_response[password_response_len] = '\0';  // Null-terminate the response
        } 
        else 
        {
            cout << "\n\n\033[31m Error receiving password response!\033[0m" << endl;
            continue;  // Retry password input on error
        }

        string password_response_str(password_response);  // Convert to std::string
        cout << "\n\n\t\t\t\t\033[36m Server response: \033[0m" << password_response_str << endl;

        if (password_response_str == "invalid password. please enter again") 
        {
            cout << "\n\n\t\033[31m Invalid password, please try again \033[0m" << endl;
            continue;  // Prompt for password again
        } 
        else if (password_response_str == "Login Successful") 
        {
            // After successful login confirmation
            cout << "\n\n\n\t\t\t\t\t\t\t\t\033[36m-------------COMMUNICATION STARTED ⌨️--------------\033[0m\n\n\n" << endl;

            long long final_shared_key = shared_key;
                    for (char c : username) {
                        final_shared_key += c;  // Simple way to append username
                    }
            
           
            // Convert modified key to AES key for chat
            unsigned char chat_aes_key[16];
            for (int i = 0; i < 16; i++) 
            {
                chat_aes_key[i] = (final_shared_key >> (8 * (15 - i))) & 0xFF;
            }

            // Generate IV for chat communication
            unsigned char chat_iv[16];
            generate_iv(chat_iv);
            send(sock, chat_iv, sizeof(chat_iv), 0);

            // Start chat communication
            while (true) 
            {
                // Get user input and send it to the server
                cout << "\nYou ("<<username<<") :";
                char message[256];  // Using a char array instead of string
                cin.getline(message, sizeof(message));  // Get user input

                // Trim the input message to remove leading/trailing spaces
                trimmessage(message);

                // Skip if the trimmed message is empty
                if (strlen(message) == 0) 
                {
                    cout << "\033[31m No input provided. Please enter a message\033[0m" << endl;
                    continue;  // Skip to the next iteration
                }

                // Encrypt message
                unsigned char encrypted_message[256];
                int encrypted_message_len = encrypt_aes(reinterpret_cast<const unsigned char*>(message), strlen(message), encrypted_message, chat_aes_key, chat_iv);

                // Send the length of the encrypted message
                send(sock, reinterpret_cast<char*>(&encrypted_message_len), sizeof(encrypted_message_len), 0);

                // Send the actual encrypted message
                send(sock, encrypted_message, encrypted_message_len, 0);

                // Check for exit condition
                if (strcmp(message, "bye") == 0)  // Use strcmp to compare char arrays
                {
                    cout << "\n\t\t\033[36m ------EXITING CHAT👋️--------\033[0m" << endl;
                    cout<<"\n\n\t\t\033[32m *****YOU DISCONNECTED AS A CLIENT******\033[0m\n";
                    exit=true;
                    exit_program=true;
                    break;  // Exit the communication loop
                }

                // Receive response from server
                // Receive the length of the encrypted response
                int response_len;
                recv(sock, reinterpret_cast<char*>(&response_len), sizeof(response_len), 0);

                // Receive the actual encrypted response
                unsigned char encrypted_response[256];
                recv(sock, encrypted_response, response_len, 0);

                // Decrypt the server response
                unsigned char plaintext_response[256];
                int decrypted_len = decrypt_aes(encrypted_response, response_len, plaintext_response, chat_aes_key, chat_iv);
                plaintext_response[decrypted_len] = '\0';  // Null-terminate the decrypted response

                cout << "\nServer: " << plaintext_response << endl;  // Show server response
            }
            
           // End of chat communication loop
            if (exit_program) 
            {
                break;  // Break out of the outer loop if exit is triggered
            }
        }
    }
}  // End of option == 2

if(option == 3)
{
 cout<<"exiting"<<endl;
 break;
}
}  // End of outer while loop
// Close the socket after the chat or error
close(sock);

return 0;
}
